/*
 * IBDS - Impulse-Based Dynamic Simulation Library
 * Copyright (c) 2003-2008 Jan Bender http://www.impulse-based.de
 *
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 * Jan Bender - Jan.Bender@impulse-based.de
 */

#ifndef __SIMMATH_H__
#define __SIMMATH_H__

#include "Common/Config.h"
#include "Vector3D.h"
#include "Matrix3x3.h"

namespace IBDS
{
	typedef Vector3D (*rungeKuttaFct)(const Real x, const Vector3D &y, void *obj);

	/** Klasse f�r Mathematik-Hilfsfunktionen, die f�r 
	  * die Simulation ben�tigt werden.
	  */
	class SimMath
	{
	public:
		/** Epsilon wird f�r Tests auf 0 verwendet */
		static Real eps;
		/** Epsilon im Quadrat */
		static Real eps2;
		/** Cash-Karp-Parameter f�r Embedded Runge-Kutta */
		static Real	a2, a3, a4, a5, a6,
				b21, b31, b32, b41, b42, b43, b51, b52, b53, b54, b61, b62, b63, b64, b65,
				c1, c3, c4, c6, dc1, dc3, dc4, dc5, dc6;

		static Vector3D lotpunkt(const Vector3D &p, const Vector3D &v, const Vector3D &s);
		static Matrix3x3 rotationsmatrix (const Vector3D &a, const Real phi);
		static Matrix3x3 orthonormalize (const Matrix3x3 &M);
		static Vector3D computeBoxIntertiaTensor (const Real m, const Real x, const Real y, const Real z);
		static Vector3D computeSphereIntertiaTensor (const Real m, const Real r);
		static int n_over_k (const int n, const int k);
		static Vector3D *localCoordinates (Matrix3x3 *rotationMatrix, Vector3D *centerOfMass, Vector3D *point);
		static Matrix3x3 crossProductMatrix (const Vector3D &r);

		static Vector3D getEulerAngles (Matrix3x3 *m);
		static Vector3D rungeKutta (rungeKuttaFct f, const Real h, const Real xn, const Vector3D &yn, void *obj, bool &result);
		static Vector3D rungeKutta (rungeKuttaFct f, const Real h, const Vector3D &yn, void *obj, bool &result);
		static Vector3D embeddedRungeKutta (rungeKuttaFct f, const Real h, const Real xn, const Vector3D &yn, Real &error, void *obj, bool &result);
		static Vector3D embeddedRungeKutta (rungeKuttaFct f, const Real h, const Vector3D &yn, Real &error, void *obj, bool &result);
		static Real computeVolume(const Vector3D &a, const Vector3D &b, const Vector3D &c, const Vector3D &d);
		static Real computeVolumeOriented(const Vector3D &a, const Vector3D &b, const Vector3D &c, const Vector3D &d);
	};
}

#endif
